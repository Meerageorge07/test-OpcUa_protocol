package controller;

import org.eclipse.milo.opcua.stack.core.types.builtin.DataValue;
import org.eclipse.milo.opcua.stack.core.types.enumerated.TimestampsToReturn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import service.OpcUaClientService;
import org.eclipse.milo.opcua.sdk.client.OpcUaClient;
import org.eclipse.milo.opcua.stack.core.types.builtin.NodeId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/opcua")
public class OpcUaController {

    private static final Logger logger = LoggerFactory.getLogger(OpcUaController.class);
    private final OpcUaClientService opcUaClientService;

    @Autowired
    public OpcUaController(OpcUaClientService opcUaClientService) {
        this.opcUaClientService = opcUaClientService;
    }

@GetMapping("/read/{nodeId}")
public Object readNode(@PathVariable String nodeId) {
    try {
    String nodeid="NS3|Numeric|"+nodeId;
      OpcUaClient client = opcUaClientService.connect();
        NodeId parsedNodeId = parseNodeId(nodeid);

        DataValue dataValue = client.readValue(1, TimestampsToReturn.Both,parsedNodeId).get();
        logger.info("value from the server is: {}",dataValue);


        return dataValue.getValue().getValue();
    } catch (Exception e) {
        e.printStackTrace();
        return "Error reading node: " + nodeId + " - " + e.getMessage();
    }
}

    private NodeId parseNodeId(String nodeIdStr) {
        String[] parts = nodeIdStr.split("\\|");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid NodeId format");
        }

        int namespaceIndex = Integer.parseInt(parts[0].substring(2)); // Extract number after 'NS'
        String identifierType = parts[1];
        String identifierValue = parts[2];

        switch (identifierType) {
            case "Numeric":
                int numericId = Integer.parseInt(identifierValue);
                return new NodeId(namespaceIndex, numericId);
            case "String":
                return new NodeId(namespaceIndex, identifierValue);

            default:
                throw new IllegalArgumentException("Unknown identifier type: " + identifierType);
        }
    }
}