//package com.example.protocol_opc;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class ProtocolOpcApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(ProtocolOpcApplication.class, args);
//	}
//
//}
package com.example.protocol_opc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"controller", "service"})
public class ProtocolOpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProtocolOpcApplication.class, args);
	}
}
