package service;

import org.eclipse.milo.opcua.sdk.client.OpcUaClient;
import org.eclipse.milo.opcua.stack.core.UaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutionException;

@Service
public class OpcUaClientService {

    @Value("${opcua.server.endpoint}")
    private String opcServerEndpoint;

    public OpcUaClient connect() throws UaException, ExecutionException, InterruptedException {
        OpcUaClient client = OpcUaClient.create(opcServerEndpoint);
        client.connect().get();
        return client;
    }


}

