package com.example.protocol_opc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProtocolOpcApplicationTests {

	@Test
	void contextLoads() {
	}

}
